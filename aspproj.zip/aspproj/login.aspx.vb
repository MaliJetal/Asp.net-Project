﻿
Imports System.Data
Imports System.Data.SqlClient
Partial Class login
    Inherits System.Web.UI.Page




End Class
