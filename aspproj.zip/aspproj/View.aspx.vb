﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class View
    Inherits System.Web.UI.Page



End Class
