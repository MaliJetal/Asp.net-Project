﻿
Partial Class Admin
    Inherits System.Web.UI.Page

    Protected Sub btnadd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnadd.Click

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("Admin") = "" Then
            Response.Redirect("Expire.aspx")

        Else
            Al.Text = Session("Admin").ToString()


        End If
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        If Session("Admin") = "" Then
            Response.Redirect("Expire.aspx")
        Else
            Session.Remove("Admin")
            Response.Redirect("login.aspx")
        End If
    End Sub
End Class
