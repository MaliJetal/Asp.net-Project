﻿
Partial Class Expire
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Session.Abandon()
        Session.RemoveAll()
        Session.Clear()

    End Sub
End Class
