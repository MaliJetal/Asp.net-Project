﻿
Partial Class aboutus
    Inherits System.Web.UI.Page

End Class
