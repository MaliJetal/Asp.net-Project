﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Home
    Inherits System.Web.UI.Page



End Class
